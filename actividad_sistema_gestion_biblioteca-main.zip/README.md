# Sistema Gestión de Biblioteca

## Ejecutar el programa

Desde la carpeta del proyecto ejecute:

```shell
python src/main.py
```

## Estructura del Proyecto

```text
README.md
src/
├── main.py
├── data/
│   └── biblioteca.py
├── models/
│   └── libro.py
└── utils/
    └── operaciones.py
```

## Descripción
- `src/main.py`: menú principal.
- `src/data/biblioteca.py`: datos iniciales de libros y categorías.
- `src/models/libro.py`: anotación de tipo `Libro`.
- `src/utils/operaciones.py`: operaciones auxiliares de la biblioteca.
