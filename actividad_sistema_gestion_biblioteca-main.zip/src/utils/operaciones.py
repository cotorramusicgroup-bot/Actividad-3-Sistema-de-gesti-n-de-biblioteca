from models.libro import Libro

def promedio_paginas(libros: list[Libro]):
    """Calcula el promedio de páginas de todos los libros"""
    total_paginas = 0

    for libro in libros:
        total_paginas += libro["paginas"]

    return total_paginas / len(libros)

def contar_libros(libros: list[Libro]):
    """Retorna la cantidad total de libros"""
    return len(libros)

# Funciones que debes implementar
def mostrar_disponibles(lista_libros: list[Libro]):
    """Muestra solo los libros que están disponibles"""
    disponibles = [libro for libro in lista_libros if libro["disponible"]]

    if not disponibles:
        print("No hay libros disponibles.")
        return

    for libro in disponibles:
        print(f'- {libro["titulo"]} | Autor: {libro["autor"]} | Páginas: {libro["paginas"]}')

def buscar_por_paginas(lista_libros: list[Libro], max_paginas: int):
    """Muestra libros con menos páginas que max_paginas"""
    encontrados = [libro for libro in lista_libros if libro["paginas"] < max_paginas]

    if not encontrados:
        print(f"No hay libros con menos de {max_paginas} páginas.")
        return

    for libro in encontrados:
        print(f'- {libro["titulo"]} | Autor: {libro["autor"]} | Páginas: {libro["paginas"]}')

def agregar_categoria(set_categorias: set[str], nueva_categoria: str):
    """Agrega una nueva categoría al set"""
    categoria = nueva_categoria.strip()
    if not categoria:
        print("La categoría no puede estar vacía.")
        return
    set_categorias.add(categoria)
    print(f'Categoría "{categoria}" agregada correctamente.')
